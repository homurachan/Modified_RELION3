/******************************************************************************
**        Title: tImageConvolution.hxx
**  Description: Image convolution with different border handling methods.
**
**       Author: Jean-Sebastien Pierrard, 2005
**               Brian Schroeder, 2006
**               Computer Science Department, University Basel (CH)
**
******************************************************************************/
namespace gravis
{



} /* Close namespace "gravis" */
