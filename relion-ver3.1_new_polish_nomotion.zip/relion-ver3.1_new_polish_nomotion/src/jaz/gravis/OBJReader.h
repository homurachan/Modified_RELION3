#ifndef __LIBGRAVIS_OBJREADER_H__
#define __LIBGRAVIS_OBJREADER_H__
#include "io/mesh/OBJReader.h"

#warning io has been restructured and bundled into gravis/io/  \
You should preferably use the <gravis/io/obj.h> header and included routines, \
unless you rely on some special use of OBJReader/OBJWriter. \
These are still available but should be included as gravis/io/OBJ {Reader,Writer} .h

#endif
